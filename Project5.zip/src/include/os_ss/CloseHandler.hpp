#ifndef CLOSEHANDLER_HPP_
#define CLOSEHANDLER_HPP_

/*
 * Author: jrahm
 * created: 2014/04/24
 * CloseHandler.hpp: <description>
 */

class CloseHandler {
public:
	virtual void onClose() = 0;
} ;

#endif /* CLOSEHANDLER_HPP_ */
