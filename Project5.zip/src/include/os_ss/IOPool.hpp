#ifndef IOPOOL_HPP_
#define IOPOOL_HPP_

/*
 * Author: jrahm
 * created: 2014/04/23
 * IOPool.hpp: <description>
 */

class IOPool {
public:
} ;

#endif /* IOPOOL_HPP_ */
