//
//  UserEventDelegate.h
//  
//
//  Created by Nicolas Charles Herbert Broeking on 4/7/14.
//
//

#ifndef ____UserEventDelegate__
#define ____UserEventDelegate__

#include <iostream>

class UserEventDelegate
{
};
#endif /* defined(____UserEventDelegate__) */
